<footer class="py-3 mt-3">
    <div class="text-center text-secondary fs-6">
        Copyright &copy; 2023 Lightning Speed Matchmaker Inc. All rights reserved.
    </div>
</footer>
