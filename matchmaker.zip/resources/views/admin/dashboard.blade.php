<x-app-layout>
    <x-admin-panel :users="$users" :subs="$subs" :matches="$matches" :pending="$pending" />
</x-app-layout>
